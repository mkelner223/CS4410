#!/usr/bin/python
import socket
host="127.0.0.1"
port=8765

# handle a single client request
class ConnectionHandler:
    def __init__(self, socket):
        self.socket = socket

    def handle(self):
        self.socket.close()

# the main server loop
def serverloop():
    serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # mark the socket so we can rebind quickly to this port number 
    # after the socket is closed
    serversocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # bind the socket to the local loopback IP address and special port
    serversocket.bind((host, port))
    # start listening with a backlog of 5 connections
    serversocket.listen(5)

    while True:
        # accept a connection
        (clientsocket, address) = serversocket.accept()
        ct = ConnectionHandler(clientsocket)
        ct.handle()

print "Server coming up... port=%d" % port
serverloop()
