
The goal of this assignment is to gain familiarity with socket-oriented
network programming by building a multi-threaded mail server. To this
end, you will need to implement a simple bare-bones mail server that
supports a subset of the regular SMTP protocol for mail delivery.

As with any server, your mail server needs to create a server socket
and wait for incoming connections. We have provided you with some
basic code to perform this function. Take a look at the initial
server.py file and find the loop in which the mail server accepts
connections. You'll notice that the initial code we provided is
single-threaded; that is, all mail processing happens serially. 

Your first task is to change the server implementation such that each
mail connection is handled separately in an independent thread. This
allows your mail server to process mail messages concurrently, and it
also avoids a very slow or crashed client from keeping your server 
busy and thus unable to process mail from normal clients. You'll need
to make the ConnectionHandler class into a thread such that all mail
handling occurs independent of the main server thread.

Second, you'll notice that the ConnectionHandler does not perform 
any mail processing at all. It simply closes the connection as 
soon as it starts up. You will need to change this so it follows
a stripped down version of the SMTP protocol. This stripped down
version looks like this:
	
	- The client needs to send a message that looks like
	HELO machinename\n

	- Your server should respond with 
	200 HELO yournetid\n

	- The client then needs to send the string
	MAIL FROM: senderemail\n

	- Your server should respond with 
	200 OK
	as long as senderemail does not contain spaces, or
	500 ERROR in senderemail\n
	if the email field has a space in it.

	- The client then needs to send the string
	RCPT TO: recevieremail\n
	
	- Your server should respond with 
	200 OK
	as long as receiveremail does not contain spaces, or
	500 ERROR in senderemail\n
	if the email field has a space in it.

	- The client then needs to send the string
	DATA
	The server should respond to this message with the
	string "354 START YOUR MESSAGE AND END WITH A PERIOD ON A LINE BY ITSELF\n"
	If the client sends any other string than DATA, the server
	should respond with "500 ERROR expecting DATA\n"
	
	- The client then sends the mail message. For the purposes
	of this assignment, you do not need to check the message 
	for well-formattedness; just take the entire message as given.
	The end of the email message is indicated by a single 
	period on a separate line, i.e. \n.\n, or by the client
	closing the socket. 

	- You should put all email, no matter what the destination,
	into a single file on disk. New emails should be appended
	to the end of the file. Make sure that separate emails are
	not interleaved -- you'll need to implement a monitor so
	only a single thread is writing to the file at any given
	time.

	- If the client fails to complete the entire transaction
	within 5 seconds, the server should send the string 
	500 TIMEOUT\n
	close the connection and terminate the thread. The on-disk
	log should not be corrupted in this case; the log should 
	appear as if the email message never arrived.
	
You can test your server by connecting to it with a telnet client.
Doing "telnet localhost 8765" (or whatever port your server is
operating at) should connect you to your server. You can type
the commands above manually and see how your server reacts.

Finally, modify the given client program so that it, too, is
concurrent, and use it to mechanically test your mail server
implementation.

If you have any questions, do not hesitate to write to
cs4410staff@systems.cs.cornell.edu

-- 

You might find that, when you try to send emails from hundreds 
of clients concurrently, your server might reset connections.
You can remedy this by increasing the number of pending 
connections (i.e. connections where the client has sent a SYN 
but the server has not responded by accepting the connection yet), 
also known as the socket backlog. The backlog is set by the 
argument to listen, which is currently 5. If you set the backlog
to a larger value, you should be able to handle hundreds of
connections per second.

--

Details About Error Handling:

If there exists an Error in the sender/receiver e-mail,
the server waits for a correct message after sending
"500 ERROR".

So a potential legal conversation looks as follows:

HELO abc12
200 OK
MAIL FROM: foo@example.com
200 OK
RCPT TO: bar @example.com
500 ERROR
RCPT TO: bar@example.com
200 OK
DATA
200 OK
(proceed as normal from here)

Here's another legal conversation:

HELO abc12
200 OK
MAIL FROM: foo @example.com
500 ERROR
MAIL FROM: foo @example.com
500 ERROR
MAIL FROM: foo@example.com
200 OK
RCPT TO: bar @example.com
500 ERROR
RCPT TO: bar@example.com
200 OK
DATA
200 OK
(proceed as normal from here)

--

Extra credit: For extra credit, create a separate "backup"
thread whose job is to create a backup of the mailbox. This
thread should be invoked every 32nd incoming message (after 32nd
mail is written on the file where you store the mails, you should
have a backup of these mails on a separate backup file). Be
sure that the backup operation occurs in a completely separate,
dedicated thread -- do not perform it "inline" during message
processing. You'll likely want to set up a monitor and condition
variables to keep track of when the backup thread needs to be
invoked.

-- 
Point breakdown:
      - 20 points: Essay questions
      - 80 points: Programming assignment
      - 10 points: Extra credit
