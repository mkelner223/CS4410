from __future__ import with_statement
from threading import Thread, Lock, Condition, Semaphore
from os import _exit as quit

# a. Add semaphore synchronization to the code below such that
#    the producer never places two widgets into the same slot, 
#    the consumer never attempts to grab a widget from an empty
#    slot, and the producer and consumer make forward progress
#    when it is possible to do so.
#
# b. Change your code to work with any number of producers and
#    consumers.

class Widget:
    idcounter = 1
    idlock = Lock()

    def __init__(self):
        with Widget.idlock:
            self.id = Widget.idcounter
            Widget.idcounter += 1

    def __str__(self):
        return "Widget#%d" % self.id

class RobotizedFactory:
    def __init__(self, size):
        self.size = size
        self.stand = []
        for i in range(0, self.size):
            self.stand.append(None)
        self.widgetloc = 0
        self.consumerloc = 0
        
    def placewidget(self, widget):
        if self.stand[self.widgetloc] != None:
            print "sync error: placed two widgets into the same slot"
            quit(1)
        self.stand[self.widgetloc] = widget
        self.widgetloc += 1
        if self.widgetloc >= self.size:
            self.widgetloc = 0

    def buywidget(self):
        if self.stand[self.consumerloc] == None:
            print "sync error: tried to grab a widget from an empty slot!"
            quit(1)
        widget = self.stand[self.consumerloc]
        self.stand[self.consumerloc] = None
        self.consumerloc += 1
        if self.consumerloc >= self.size:
            self.consumerloc = 0
        return widget

class Producer(Thread):
    def __init__(self):
        Thread.__init__(self)

    def run(self):
        global factory

        while True:
            mywidget = Widget()
            print "producer: produced %s" % mywidget
            factory.placewidget(mywidget)
            print "producer: placed %s on stand" % mywidget

class Consumer(Thread):
    def __init__(self):
        Thread.__init__(self)

    def run(self):
        global factory

        while True:
            print "consumer: need to buy something"
            mywidget = factory.buywidget()
            print "consumer: got %s from stand" % mywidget
            
factory = RobotizedFactory(10)
p = Producer()
c = Consumer()
p.start()
c.start()
