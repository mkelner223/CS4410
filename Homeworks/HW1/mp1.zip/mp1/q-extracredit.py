# build a sieve of erasthotenes. such a sieve is used to determine
# prime numbers, with filters in place to eliminate multiples of 
# primes.
#
# you will need a producer thread, that simply produces numbers 
# 2 through 1000. these are all candidates for prime numbers.
#
# you will need a channel, through which numbers are communicated. this
# channel is analogous to the bounded buffer used in the producer 
# consumer problem, except it can hold as few as one item at a time.
#
# you will need a consumer thread, with a given channel as an input.
# any number that makes its way to the consumer is considered a prime
# number. whenever a prime reaches the consumer, the consumer should
# print it, create a filter thread around this prime number and with
# the current channel as the new filter's input, and the filter's
# output as the consumer's new input.
#
# you will need filter threads, forked off by the consumer thread
# with a particular prime. these threads should read numbers from
# their input channels, check if the number is divisable by the 
# prime with which they have been tasked from eliminating from 
# the stream, and if the number is not evenly divisable by their
# prime, simply pass it on to their output.

# use either monitors and condition variables, or semaphores.


