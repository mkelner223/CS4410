from __future__ import with_statement
from threading import Thread, Lock, Condition, Semaphore
from os import _exit as quit
import time, random

# modify the parent thread to create a child thread, 
# wait for it to print to the screen 5 times,
# then the parent should print that the child is done.
# 
# the parent and child should use monitors and condition
# variables for synchronization

class Child(Thread):
    def __init__(self):
        Thread.__init__(self)
    
    def run(self):
        for i in range(0, 5):
            print "hello from child", i
        pass

class Parent(Thread):
    def __init__(self):
        Thread.__init__(self)
    
    def run(self):
        pass


p = Parent()
p.start()



