
Please create a new file called answers.txt that answers all 
of the subparts of the questions asked in files q1.py through
q12.py.

