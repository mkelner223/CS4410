from __future__ import with_statement
from threading import Thread, Lock, Condition, Semaphore

# a. When both threads terminate, what is the largest possible value
#    count may have?
# b. When both threads terminate, what is the smallest possible value
#    count may have?
# c. What other values can can count have when both threads have 
#    terminated?
# d. Add appropriate synchronization such that updates to count
#    occur in a critical section, ensuring that the count is 
#    always at 0 when the two threads terminate.

count = 0
class Worker1(Thread):
    def __init__(self):
        Thread.__init__(self)

    def run(self):
        global count
        for i in range(0, 10000):
            count += 1

class Worker2(Thread):
    def __init__(self):
        Thread.__init__(self)

    def run(self):
        global count
        for j in range(0, 10000):
            count -= 1

w1 = Worker1()
w2 = Worker2()
w1.start()
w2.start()
