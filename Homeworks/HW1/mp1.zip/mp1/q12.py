from __future__ import with_statement
from threading import Thread, Lock, Condition, Semaphore
from os import _exit as quit
import sys, time, random

# iterate over the entire tree such that every node is processed by a 
# separate thread, and a parent is not processed until all of its
# children have been processed. 
#
# you should modify the "process" method to fork threads and 
# synchronize appropriately between threads. A thread processing
# a tree node should simply output the contents of the tree node
# and exit. Note that for a tree with three children (1, 2 and 3), 
# there are six different permissable (i.e. correct) outputs. The
# particular output you get on each run depends on the scheduler's
# actions.
# 
# Use monitors and condition variables to solve this problem

class TreeNode():
    def __init__(self, content):
        self.children = []
        self.content = content

    def __str__(self):
        return "TN(%d, %d children)" % (self.content, len(self.children))

    def addchild(self, child):
        self.children.append(child)

    def process(self):
        print self.content
        for child in self.children:
            child.process()

def buildtree():
    stack = [TreeNode("top")]
    depth = 0
    for line in sys.stdin.readlines():
        d = line.count("\t")
        if d <= depth and depth > 0:
            for i in range(0, depth-d):
                stack.pop()
        tn = TreeNode(line.strip())
        stack[len(stack)-1].addchild(tn)
        stack.append(tn)
        if d > depth+1:
            print "error in tree nesting"
            quit(0)
        else:
            depth = d
    return stack[0]

top = buildtree()
top.process()





